<footer class="footer mt-auto bg-light">
    <div class="container text-center">
        <span class="text-muted">&copy; 2024 NikeShop Indonesia.</span>
    </div>
</footer>